<?php

function sq_sc_button_css(){

	wp_enqueue_style('sq-sc-button-icon', SCULPTUREQODE__PLUGIN_URL . 'admin/sq-button/sq-shortcode-button-css.css', array(), '1.0.0', '');
	
}
add_action('admin_enqueue_scripts', 'sq_sc_button_css');

function sq_sc_add_mce_button(){

	if ( !current_user_can( 'edit_posts' ) && !current_user_can( 'edit_pages' ) ) :
		return;
	endif;

	if ( get_user_option( 'rich_editing' ) ) :
		add_filter( 'mce_external_plugins', 'sq_sc_add_tinymce_plugin' );
		add_filter( 'mce_buttons', 'sq_sc_register_mce_button' );
	endif;
}
add_action('admin_head', 'sq_sc_add_mce_button');


function sq_sc_add_tinymce_plugin( $plugin_array ){
	$plugin_array['sq_sc_mce_button'] = SCULPTUREQODE__PLUGIN_URL . 'admin/sq-button/shortcode-button.js';
	return $plugin_array;
}

function sq_sc_register_mce_button( $buttons ){
	array_push( $buttons, 'sq_sc_mce_button' );
	return $buttons;
}

function sq_sc_shortcode_empty_paragraph($content){
	$array = array (
		'<p>[' => '[',
		']</p>' => ']',
		']<br />' => ']'
	);
	$content = strtr($content, $array);
	return $content;
}
add_filter('the_content', 'sq_sc_shortcode_empty_paragraph');

