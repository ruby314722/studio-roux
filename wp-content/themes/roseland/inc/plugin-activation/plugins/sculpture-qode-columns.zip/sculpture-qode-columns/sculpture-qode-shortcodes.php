<?php
/**
* Plugin Name: Sculpture Qode Columns
* Plugin URI: http://sculptureqode.com
* Description: This plugin provides all the required shortcodes for Sculpture Qodes's themes.
* Version: 1.0
* Author: Sculpture Qode Themes
* Author URI: http://sculptureqode.com
* License:
*/

define( 'SCULPTUREQODE_VERSION', '1.0' );
define( 'SCULPTUREQODE__MINIMUM_WP_VERSION', '4.0' );
define( 'SCULPTUREQODE__PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SCULPTUREQODE__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SCULPTUREQODE_DELETE_LIMIT', 100000 );


/* Shortcode Button
*****************************************/
require_once( SCULPTUREQODE__PLUGIN_DIR . 'admin/sq-button/sq-shortcode-button.php' );

//Columns
require_once( SCULPTUREQODE__PLUGIN_DIR . 'shortcodes/columns/sq-columns.php' );

// Enqueue Scripts
function sq_sc_enqueue_scripts(){	
	wp_enqueue_style( 'sq-shortcode-styles', SCULPTUREQODE__PLUGIN_URL . 'inc/css/style.css' );	
}
add_action( 'wp_enqueue_scripts', 'sq_sc_enqueue_scripts' );

