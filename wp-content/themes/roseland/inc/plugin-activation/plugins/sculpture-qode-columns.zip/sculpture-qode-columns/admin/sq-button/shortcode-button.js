
(function() {
	tinymce.PluginManager.add('sq_sc_mce_button', function(editor, url) {
		editor.addButton('sq_sc_mce_button', {
			title: 'Sculpture Qode Columns',
            type: 'menubutton',
            icon: 'icon sq-sc-admin-button',
			menu: [{
				text: 'Columns',
				menu: [{
					text: 'Row',
					onclick: function() {
						editor.insertContent('[row]Your Content...[/row]');
					}
				},{
					text: '1/2 + 1/2',
					onclick: function() {
						editor.insertContent('[one_half]Your Content...[/one_half][one_half]Your Content...[/one_half]');
					}
				}, {
					text: '1/3 + 1/3 + 1/3',
					onclick: function() {
						editor.insertContent('[one_third]Your Content...[/one_third][one_third]Your Content...[/one_third][one_third]Your Content...[/one_third]');
					}
				}, {
					text: '1/4 + 1/4 + 1/4 + 1/4',
					onclick: function() {
						editor.insertContent('[one_fourth]Your Content...[/one_fourth][one_fourth]Your Content...[/one_fourth][one_fourth]Your Content...[/one_fourth][one_fourth]Your Content...[/one_fourth]');
					}
				}, {
					text: '1/5 + 1/5 + 1/5 + 1/5 + 1/5',
					onclick: function() {
						editor.insertContent('[one_fifth]Your Content...[/one_fifth][one_fifth]Your Content...[/one_fifth][one_fifth]Your Content...[/one_fifth][one_fifth]Your Content...[/one_fifth][one_fifth]Your Content...[/one_fifth]');
					}
				}, {
					text: '1/6 + 1/6 + 1/6 + 1/6 + 1/6 + 1/6',
					onclick: function() {
						editor.insertContent('[one_sixth]Your Content...[/one_sixth][one_sixth]Your Content...[/one_sixth][one_sixth]Your Content...[/one_sixth][one_sixth]Your Content...[/one_sixth][one_sixth]Your Content...[/one_sixth][one_sixth]Your Content...[/one_sixth]');
					}
				}, {
					text: '2/3 + 1/3',
					onclick: function() {
						editor.insertContent('[two_third]Your Content...[/two_third][one_third]Your Content...[/one_third]');
					}
				}, {
					text: '1/3 + 2/3',
					onclick: function() {
						editor.insertContent('[one_third]Your Content...[/one_third][two_third]Your Content...[/two_third]');
					}
				}, {
					text: '3/4 + 1/4',
					onclick: function() {
						editor.insertContent('[three_fourth]Your Content...[/three_fourth][one_fourth]Your Content...[/one_fourth]');
					}
				}, {
					text: '1/4 + 1/2 + 1/4',
					onclick: function() {
						editor.insertContent('[one_fourth]Your Content...[/one_fourth][one_half]Your Content...[/one_half][one_fourth]Your Content...[/one_fourth]');
					}
				}, {
					text: '1/4 + 1/4 + 1/2',
					onclick: function() {
						editor.insertContent('[one_fourth]Your Content...[/one_fourth][one_fourth]Your Content...[/one_fourth][one_half]Your Content...[/one_half]');
					}
				},]
			}]
		});
	});
})();