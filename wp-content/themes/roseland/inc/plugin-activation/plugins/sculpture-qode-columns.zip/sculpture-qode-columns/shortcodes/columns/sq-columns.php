<?php 
function sq_sc_one_third( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-3">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_third', 'sq_sc_one_third');

function sq_sc_two_third( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-2-3">' . do_shortcode($content) . '</div>';
}
add_shortcode('two_third', 'sq_sc_two_third');

function sq_sc_one_half( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-2">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_half', 'sq_sc_one_half');

function sq_sc_one_fourth( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-4">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_fourth', 'sq_sc_one_fourth');

function sq_sc_three_fourth( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-3-4">' . do_shortcode($content) . '</div>';
}
add_shortcode('three_fourth', 'sq_sc_three_fourth');

function sq_sc_one_fifth( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-5">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_fifth', 'sq_sc_one_fifth');

function sq_sc_two_fifth( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-2-5">' . do_shortcode($content) . '</div>';
}
add_shortcode('two_fifth', 'sq_sc_two_fifth');

function sq_sc_three_fifth( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-3-5">' . do_shortcode($content) . '</div>';
}
add_shortcode('three_fifth', 'sq_sc_three_fifth');

function sq_sc_four_fifth( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-4-5">' . do_shortcode($content) . '</div>';
}
add_shortcode('four_fifth', 'sq_sc_four_fifth');

function sq_sc_one_sixth( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-6">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_sixth', 'sq_sc_one_sixth');

function sq_sc_five_sixth( $atts, $content = null ) {
   return '<div class="sq-sc-column sq-sc-column-5-6">' . do_shortcode($content) . '</div>';
}
add_shortcode('five_sixth', 'sq_sc_five_sixth');

function sq_sc_row( $atts, $content = null ) {
   return '<div class="sq-sc-row">' . do_shortcode($content) . '</div>';
}
add_shortcode('row', 'sq_sc_row');